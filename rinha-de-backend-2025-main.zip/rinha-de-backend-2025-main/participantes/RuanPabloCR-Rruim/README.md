# Rinha Backend - Dotnet

**Repositório**: https://github.com/RuanPabloCR/Rinha-backend

## Tecnologias Utilizadas
- **Linguagem**:  C#
- **Framework**: .NET 9
- **Storage**: Redis
- **Load Balancer**: nginx
- **Conteinerização**: Docker
