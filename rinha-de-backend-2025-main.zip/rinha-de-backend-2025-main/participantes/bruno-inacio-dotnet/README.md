# Rinha de Backend 2025 - Bruno Inácio

Implementação do desafio da **Rinha de Backend 2025** utilizando **.NET**.

Repositório do projeto: [https://github.com/BrunoInacio45/rinha-backend-2025](https://github.com/BrunoInacio45/rinha-backend-2025)

## Tecnologias utilizadas

- **Linguagem**: c#
- **Loadbalancer**: nginx
- **Database**: PostgreSQL, Redis