# 🦀 Rinha de Backend 2025 - Go

Este repositório contém a minha participação na **Rinha de Backend 2025**, implementada em **Go**.

## 🚀 Como rodar

Certifique-se de ter o **Docker** e o **Docker Compose** instalados.

```bash
git clone https://github.com/andersongomes001/rinha-2025-go.git
cd rinha-2025-go
docker compose up --build
```
