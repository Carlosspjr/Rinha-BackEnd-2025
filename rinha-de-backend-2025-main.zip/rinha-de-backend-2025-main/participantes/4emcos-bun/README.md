# Rinha de Backend 2025

Implementation of the **Rinha de Backend 2025** challenge using **Bun**.

- Project repository: [rinha-de-backend-2025-bun](https://github.com/4emcos/rinha-de-backend-2025-bun)  
- In-memory database: [writer-go](https://github.com/4emcos/writer-go)  