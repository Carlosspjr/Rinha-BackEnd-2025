# rinha-backend-lean4

This repository contains a Lean 4 project scaffolding to port the provided C HTTP server/client code into Lean 4.

---

**Source code:** [Click here](https://github.com/cleissonbarbosa/rinha-backend-lean4)

---

## Technologies

- **Lean 4 and C**
- **HaProxy**
- **Docker**

---
