# Rinha de Backend 2025

Implementação do desafio da **Rinha de Backend 2025** utilizando **NestJS**.

- NestJs
- NGINX
- Typeorm
- Redis
- Postgres
- BullMq

Repositório do projeto: https://github.com/alvesa/rinha-de-backend-2025/tree/rinha
