# Rinha de Backend 2025 - Golang

## Tecnologias

- Golang para criação da API e um worker.

  - Fiber para o framework web.
  - pgx para o driver do PostgreSQL.
  - go-redis para o cliente Redis.

- Redis para filas.
- PostgreSQL para o banco de dados relacional.
- NGINX como balanceador de cargas.
