# Rinha de Backend 2025
## Implementação do desafio da Rinha de Backend 2025 utilizando Go.

Repositório do projeto: https://github.com/breno5g/rinha-backend-2025

##Tecnologias utilizadas
- Linguagem: Go
- Loadbalancer: Nginx
- Servidor HTTP: standard
- Stream e cache: Redis
- Orquestração: Docker + Docker Compose