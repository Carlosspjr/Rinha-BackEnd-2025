# Rinha de Backend 2025

## Tecnologias utilizadas
- **Linguagem:** Node
- **Armazenamento/Fila:** Redis
- **Balanceador:** Nginx
- **Orquestração:** Docker Compose, Docker

## Repositório
[https://github.com/antooniodev/rinha-backend-2025](https://github.com/antooniodev/rinha-backend-2025)
