# cgb-go-v1 - Rinha de Backend 2025

Sistema de intermediação de pagamentos desenvolvido em Go.


## 📝 Repositório

**Código fonte**: https://github.com/cicerogb/cgb-go-v1-source