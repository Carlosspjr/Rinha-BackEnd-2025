# cgb-go-v2 - Rinha de Backend 2025

Sistema de intermediação de pagamentos desenvolvido em Go - Versão 2.


## 📝 Repositório

**Código fonte**: https://github.com/cicerogb/cgb-go-v2-source