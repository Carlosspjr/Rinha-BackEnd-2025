# Projeto
Projeto em elixir usando o framework Phoenix para criar uma API RESTful que processa requisições de forma assíncrona.
Storage de dados feito com PostgreSQL.
