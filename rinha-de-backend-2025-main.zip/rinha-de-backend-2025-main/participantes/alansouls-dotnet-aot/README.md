# Rinha de Backend 2025 - Implementação em C#/.NET Native AOT

Repo: https://github.com/alansouls/rinha_backend

Tecnologias
- ASP.NET Core Native AOT
- Console App Native AOT
- UDP Sockets para comunicação
- DB in memory sincronizado via UDP
- e só

