## Aqui está meu humilde backend

## REPO
https://github.com/Adryan1928/rinha-de-backend-2025

## Stacks
Usei o FastApi, nginx como load balancer, httpx e redis.

Acho que foi só isso mesmo

## Redes

Instagram: @adryaneryk
linkedin: https://www.linkedin.com/in/adryan-eryk-oliveira-leite-0b0551193/