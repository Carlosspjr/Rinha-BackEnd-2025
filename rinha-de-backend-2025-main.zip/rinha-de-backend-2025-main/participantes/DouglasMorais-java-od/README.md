# Rinha de Backend 2025 - Java Quarkus
Only default payment processor version

## Tecnologias

- **Java 21 Native GraalVM**
- **Quarkus**
- **Nginx**
- **Docker**

## Repositório

[GitHub](https://github.com/morais15/rinha-backend-2025-quarkus)