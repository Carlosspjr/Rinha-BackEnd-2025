# Cash Fighter - Payment Processing v1

Esse repo tem como objetivo fazer um projeto de backend que faz as requisições para meios de pagamentos de forma assincrona para a [*Rinha de backend 2025*](https://github.com/zanfranceschi/rinha-de-backend-2025).

## Stack / Arquitetura

- Bun / TypeScript
- Redis database
- Redis fila
- Nginx Load Balancer