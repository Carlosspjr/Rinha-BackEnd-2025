# Rinha de Backend - 2025

# Player 456 - bravo com o hardware de microondas

![Player456.webp](Player456.webp)

Rinha #3  - https://github.com/zanfranceschi/rinha-de-backend-2025

Fonte - https://github.com/boaglio/player456-rinha-de-backend-2025/tree/player456

##  Javinha na Rinha de back end 2025

* Java 24 (GraalVM 24.0.2+11.1)
* Spring Boot 3.5.3 (native)
* Redis 7.2
* NGinx 1.29
