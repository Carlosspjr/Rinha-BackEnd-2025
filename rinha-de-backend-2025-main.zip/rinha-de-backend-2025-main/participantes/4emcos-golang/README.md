# Rinha de Backend 2025

Implementação do desafio da **Rinha de Backend 2025** utilizando **Go**.

Repositório do projeto: https://github.com/4emcos/rinha-de-backend-2025-golang

