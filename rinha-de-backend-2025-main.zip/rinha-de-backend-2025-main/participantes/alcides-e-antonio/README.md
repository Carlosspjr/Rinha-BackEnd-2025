# Rinha de Backend 2025

Repo: https://github.com/arrodrigues/rinha-backend-2025

Tecnologias
- Kotlin 2.2
- Vert.x 5
- Postgres 16.9
- HAProxy 3.2.3

