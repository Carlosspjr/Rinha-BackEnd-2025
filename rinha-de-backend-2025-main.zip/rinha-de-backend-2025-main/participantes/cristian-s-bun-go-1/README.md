Usando Bun (TS) como principal back-end e Go como sqlite writer (wtf né)

Uso de SQLITE como DB
Uso de NATS como principal fila
Uso de REDIS para guardar dados entre as instancias

Link do repo: https://github.com/Chr1s0Blood/rinha-de-backend-2025-bun-go

Só to subindo pra testar, localmente eu peguei 270k de lucro... tenho medo do teste previo

Vou refazer essa sub depois