***Rinha de Backend 2025 - ruby***

Este repositório contém a minha participação na Rinha de Backend 2025, implementada em ruby.

🚀 Tecnologias Utilizadas
- Sinatra
- Sequel
- Redis
- Postgresql