# Rinha de Backend 2025

Implementação do desafio da **Rinha de Backend 2025** utilizando **.NET 9 NATIVAO**.

- .NET 10 AOT
- NGINX
- UNIX SOCKET
- FÉ

Repositório do projeto: https://github.com/angryTuxx/rinha-de-backend-2025-csharp-aot/tree/feature/deploy

