# 🚀 Backend em Rust com Redis como Mensageria

Resumindo a stack ---> **Rust + Redis + nginx + tokio + threads** 🦀❤️

