As tecnologias usadas foram .net10 preview para a aplicação, redis como storage e nginx para load balance

Link: https://github.com/White1Lopes/Rinha2025