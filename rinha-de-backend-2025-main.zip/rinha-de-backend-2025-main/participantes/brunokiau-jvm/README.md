# Rinha de Backend 2025

Repo: https://github.com/brunokiau/rb25-java

##Tecnologias utilizadas
- java
- hproxy
