# Resultados Finais da Rinha de Backend 2025

Atualizado em **Thu Aug 21 19:42:57 -03 2025**


| ranking | participante    | p99       | bônus p99 (%) | multa ($)     | lucro          | submissão                                                                   |
| ------- | --------------- | --------- | ------------- | ------------- | -------------- | --------------------------------------------------------------------------- |
| 1       | ricassiocost... | 2.55ms    | 17%           | 0             | 1949876.384625 | [dir→](./participantes/ricassiocosta-node)                                  |
| 2       | RuanPabloCR-... | 2.09ms    | 18%           | 0             | 1937542.21209  | [dir→](./participantes/RuanPabloCR-Rruim)                                   |
| 3       | lucas-lauren... | 2.18ms    | 18%           | 0             | 1935735.84744  | [dir→](./participantes/lucas-laurentino-go)                                 |
| 4       | marcelo-dias... | 2.75ms    | 17%           | 0             | 1924354.70955  | [dir→](./participantes/marcelo-dias-final)                                  |
| 5       | marcelo-dias    | 2.42ms    | 17%           | 0             | 1923913.455165 | [dir→](./participantes/marcelo-dias)                                        |
| 6       | danilosantan... | 2.53ms    | 17%           | 0             | 1922071.024575 | [dir→](./participantes/danilosantana-dotnet)                                |
| 7       | yanpitangui-... | 2.49ms    | 17%           | 0             | 1919914.0155   | [dir→](./participantes/yanpitangui-dotnet-v2)                               |
| 8       | cristian-s-n... | 3.46ms    | 15%           | 0             | 1918576.7607   | [dir→](./participantes/cristian-s-node-1)                                   |
| 9       | tarcisiozf-asm  | 2.58ms    | 17%           | 0             | 1914863.165865 | [dir→](./participantes/tarcisiozf-asm)                                      |
| 10      | jccl            | 3.19ms    | 16%           | 0             | 1906926.9087   | [dir→](./participantes/jccl)                                                |
| 11      | igor-gregori... | 3.05ms    | 16%           | 0             | 1906837.59798  | [dir→](./participantes/igor-gregori-bun-v2)                                 |
| 12      | igor-gregori... | 3.08ms    | 16%           | 0             | 1906652.69688  | [dir→](./participantes/igor-gregori-bun-v1)                                 |
| 13      | jacarerj-csharp | 3.11ms    | 16%           | 0             | 1904925.79038  | [dir→](./participantes/jacarerj-csharp)                                     |
| 14      | leorcvargas-... | 3.24ms    | 16%           | 0             | 1904306.19726  | [dir→](./participantes/leorcvargas-stable)                                  |
| 15      | tarcisiozf-a... | 3.14ms    | 16%           | 0             | 1898320.98354  | [dir→](./participantes/tarcisiozf-asm-2)                                    |
| 16      | jairoandre-k... | 3.28ms    | 15%           | 0             | 1889817.6021   | [dir→](./participantes/jairoandre-kotlin)                                   |
| 17      | vfabricio-ud... | 3.65ms    | 15%           | 0             | 1889332.702875 | [dir→](./participantes/vfabricio-uds-quick)                                 |
| 18      | jairoandre-g... | 3.66ms    | 15%           | 0             | 1889236.5531   | [dir→](./participantes/jairoandre-go-v2)                                    |
| 19      | igor-lucas-c... | 3.26ms    | 15%           | 0             | 1888952.94585  | [dir→](./participantes/igor-lucas-csharp2)                                  |
| 20      | jeffersonagu... | 3.41ms    | 15%           | 0             | 1887749.34435  | [dir→](./participantes/jeffersonaguiar-nodejs)                              |
| 21      | jairoandre      | 3.29ms    | 15%           | 0             | 1887653.194575 | [dir→](./participantes/jairoandre)                                          |
| 22      | silvaangelo     | 4.33ms    | 13%           | 0             | 1840734.77451  | [dir→](./participantes/silvaangelo)                                         |
| 23      | uchoamp-zig+... | 2.56ms    | 17%           | 0             | 1820925.948465 | [dir→](./participantes/uchoamp-zig+nginx)                                   |
| 24      | mauricio-cantu  | 5.81ms    | 10%           | 0             | 1804953.4107   | [dir→](./participantes/mauricio-cantu)                                      |
| 25      | lecosas-java... | 2.49ms    | 17%           | 0             | 1785955.65876  | [dir→](./participantes/lecosas-java-spring-graalvm)                         |
| 26      | lecosas-java... | 2.58ms    | 17%           | 0             | 1782057.559815 | [dir→](./participantes/lecosas-java-spring-graalvm-6)                       |
| 27      | lecosas-java... | 2.61ms    | 17%           | 0             | 1775452.81914  | [dir→](./participantes/lecosas-java-spring-graalvm-3)                       |
| 28      | lecosas-java... | 2.38ms    | 17%           | 0             | 1775379.62862  | [dir→](./participantes/lecosas-java-spring-graalvm-2)                       |
| 29      | davidalecrim... | 2.27ms    | 17%           | 0             | 1667144.220885 | [dir→](./participantes/davidalecrim1-go-4)                                  |
| 30      | davidalecrim... | 2.34ms    | 17%           | 0             | 1667078.77167  | [dir→](./participantes/davidalecrim1-go-5)                                  |
| 31      | davidalecrim... | 2.32ms    | 17%           | 0             | 1666969.689645 | [dir→](./participantes/davidalecrim1-go-6)                                  |
| 32      | passos-mathe... | 14.15ms   | 0%            | 0             | 1657299.717    | [dir→](./participantes/passos-matheus-python-16reqs-timeout-aptivo)         |
| 33      | thomaz-maldo... | 38.34ms   | 0%            | 0             | 1649946.3795   | [dir→](./participantes/thomaz-maldonado-go-1)                               |
| 34      | 4emcos-bun      | 2.96ms    | 16%           | 0             | 1649715.5238   | [dir→](./participantes/4emcos-bun)                                          |
| 35      | breno5g         | 11.02ms   | 0%            | 0             | 1648396.314    | [dir→](./participantes/breno5g)                                             |
| 36      | jvcouto-go-2    | 118.61ms  | 0%            | 0             | 1639788.2475   | [dir→](./participantes/jvcouto-go-2)                                        |
| 37      | jvcouto-go-3    | 194.47ms  | 0%            | 0             | 1637398.488    | [dir→](./participantes/jvcouto-go-3)                                        |
| 38      | gupers          | 2.84ms    | 16%           | 0             | 1629837.60894  | [dir→](./participantes/gupers)                                              |
| 39      | gupers-v2       | 2.97ms    | 16%           | 0             | 1629772.71912  | [dir→](./participantes/gupers-v2)                                           |
| 40      | niltonkummer... | 2.55ms    | 17%           | 0             | 1619060.864265 | [dir→](./participantes/niltonkummer-haproxy)                                |
| 41      | niltonkummer    | 2.5ms     | 17%           | 0             | 1618973.598645 | [dir→](./participantes/niltonkummer)                                        |
| 42      | david-delta-... | 2.43ms    | 17%           | 0             | 1599622.44741  | [dir→](./participantes/david-delta-sierra-go)                               |
| 43      | ricardovhz      | 59.59ms   | 0%            | 0             | 1586659.557    | [dir→](./participantes/ricardovhz)                                          |
| 44      | anibalferrei... | 4.27ms    | 13%           | 0             | 1585356.641835 | [dir→](./participantes/anibalferreira-rust-2)                               |
| 45      | michelolivei... | 3.21ms    | 16%           | 0             | 1579966.64244  | [dir→](./participantes/micheloliveira-com-dotnet-csharp-redis-grpc-haproxy) |
| 46      | michelolivei... | 2.79ms    | 16%           | 0             | 1576964.26722  | [dir→](./participantes/micheloliveira-com-dotnet-csharp-redis-grpc)         |
| 47      | willianmarqu... | 3.53ms    | 15%           | 0             | 1558082.8935   | [dir→](./participantes/willianmarquess-node)                                |
| 48      | arthur-isvi-... | 3.75ms    | 15%           | 0             | 1553325.20895  | [dir→](./participantes/arthur-isvi-php-hyperf-nano)                         |
| 49      | lckrugel-go     | 394.08ms  | 0%            | 0             | 1546789.1295   | [dir→](./participantes/lckrugel-go)                                         |
| 50      | DouglasMorai... | 5.76ms    | 10%           | 0             | 1535813.37855  | [dir→](./participantes/DouglasMorais-java-od)                               |
| 51      | lecosas-java... | 3.18ms    | 16%           | 0             | 1521879.78744  | [dir→](./participantes/lecosas-java-spring-graalvm-4-direct-final)          |
| 52      | asfernandes-... | 84.69ms   | 0%            | 0             | 1510391.1615   | [dir→](./participantes/asfernandes-haproxy-mongoose-lmdb)                   |
| 53      | diegodario-go   | 6.17ms    | 10%           | 0             | 1508916.0075   | [dir→](./participantes/diegodario-go)                                       |
| 54      | pru-async-v2    | 5.2ms     | 12%           | 0             | 1466187.72048  | [dir→](./participantes/pru-async-v2)                                        |
| 55      | vrtineu         | 65.95ms   | 0%            | 0             | 1425840.7125   | [dir→](./participantes/vrtineu)                                             |
| 56      | gabxdev-java-2  | 4.42ms    | 13%           | 0             | 1421454.989535 | [dir→](./participantes/gabxdev-java-2)                                      |
| 57      | chriscorrales   | 45.99ms   | 0%            | 0             | 1416299.7195   | [dir→](./participantes/chriscorrales)                                       |
| 58      | rodrigocalde... | 3.34ms    | 15%           | 0             | 1388633.095425 | [dir→](./participantes/rodrigocaldeira-dart)                                |
| 59      | asfernandes-... | 3.19ms    | 16%           | 0             | 1386026.32074  | [dir→](./participantes/asfernandes-boost-lmdb)                              |
| 60      | igor-lucas-c... | 3.58ms    | 15%           | 604824.0093   | 1382454.8784   | [dir→](./participantes/igor-lucas-csharp)                                   |
| 61      | joyce-go-2      | 2.09ms    | 18%           | 580877.422125 | 1377509.315325 | [dir→](./participantes/joyce-go-2)                                          |
| 62      | artschur        | 7.9ms     | 6%            | 0             | 1371950.22225  | [dir→](./participantes/artschur)                                            |
| 63      | rafaelviefe     | 2.35ms    | 17%           | 578176.386375 | 1354584.67665  | [dir→](./participantes/rafaelviefe)                                         |
| 64      | andersongome... | 85.97ms   | 0%            | 0             | 1348034.883    | [dir→](./participantes/andersongomes001-go)                                 |
| 65      | joyce-go-4      | 2.76ms    | 16%           | 580649.213025 | 1343788.178715 | [dir→](./participantes/joyce-go-4)                                          |
| 66      | marcelo-dias... | 2.34ms    | 17%           | 572086.95075  | 1340317.9989   | [dir→](./participantes/marcelo-dias-fall)                                   |
| 67      | cristian-s-n... | 3.27ms    | 15%           | 584103.507225 | 1335093.7308   | [dir→](./participantes/cristian-s-node-3-http-2)                            |
| 68      | jeifersonalm... | 3.17ms    | 16%           | 576179.55675  | 1333444.11705  | [dir→](./participantes/jeifersonalmeida-stage-2)                            |
| 69      | rodrigocalde... | 3.49ms    | 15%           | 579775.534275 | 1325201.2212   | [dir→](./participantes/rodrigocaldeira-elixir)                              |
| 70      | svaan1-go       | 6.56ms    | 9%            | 0             | 1323966.371775 | [dir→](./participantes/svaan1-go)                                           |
| 71      | jaofreire-e-... | 3.29ms    | 15%           | 578004.176925 | 1321152.4044   | [dir→](./participantes/jaofreire-e-isaias-dotnet)                           |
| 72      | rbenatti8       | 3.82ms    | 14%           | 583451.300775 | 1316932.936035 | [dir→](./participantes/rbenatti8)                                           |
| 73      | davi64lima-bun  | 2.94ms    | 16%           | 568862.760375 | 1316510.959725 | [dir→](./participantes/davi64lima-bun)                                      |
| 74      | maxwellolive... | 3.32ms    | 15%           | 575873.242875 | 1316281.698    | [dir→](./participantes/maxwelloliveira01-dotnet)                            |
| 75      | jeifersonalm... | 3.44ms    | 15%           | 575466.508575 | 1315352.0196   | [dir→](./participantes/jeifersonalmeida-stage-1)                            |
| 76      | lecosas-java... | 1.96ms    | 18%           | 0             | 1309820.20455  | [dir→](./participantes/lecosas-java-spring-graalvm-3-final)                 |
| 77      | yanpitangui-... | 3.05ms    | 16%           | 564570.576675 | 1306577.620305 | [dir→](./participantes/yanpitangui-dotnet)                                  |
| 78      | gaoliveira21    | 89.9ms    | 0%            | 0             | 1298560.9065   | [dir→](./participantes/gaoliveira21)                                        |
| 79      | thomaz-golang-2 | 78.19ms   | 0%            | 0             | 1298362.4115   | [dir→](./participantes/thomaz-golang-2)                                     |
| 80      | lucasgoveia     | 2.39ms    | 17%           | 0             | 1295610.843735 | [dir→](./participantes/lucasgoveia)                                         |
| 81      | lhuizf-bun      | 15.85ms   | 0%            | 0             | 1294594.014    | [dir→](./participantes/lhuizf-bun)                                          |
| 82      | jonhkr          | 85.3ms    | 0%            | 0             | 1292982.5955   | [dir→](./participantes/jonhkr)                                              |
| 83      | ogabriel-elixir | 4.26ms    | 13%           | 579586.903875 | 1291650.81435  | [dir→](./participantes/ogabriel-elixir)                                     |
| 84      | rafaelvieira    | 4.61ms    | 13%           | 579311.7477   | 1291037.60916  | [dir→](./participantes/rafaelvieira)                                        |
| 85      | wesleymatosd... | 2.86ms    | 16%           | 553611.908325 | 1281216.130695 | [dir→](./participantes/wesleymatosdev-rust)                                 |
| 86      | lecosas-java... | 2.35ms    | 17%           | 546454.058325 | 1280263.79379  | [dir→](./participantes/lecosas-java-spring-graalvm-3-limited-worker)        |
| 87      | uchoamp-zig     | 2.57ms    | 17%           | 545983.53495  | 1279161.42474  | [dir→](./participantes/uchoamp-zig)                                         |
| 88      | igortxra        | 5.18ms    | 12%           | 576111.136125 | 1267444.499475 | [dir→](./participantes/igortxra)                                            |
| 89      | diogoloff-fpc   | 11.3ms    | 0%            | 0             | 1260764.451    | [dir→](./participantes/diogoloff-fpc)                                       |
| 90      | railson-ferr... | 33.43ms   | 0%            | 0             | 1257449.5845   | [dir→](./participantes/railson-ferreira-dart)                               |
| 91      | samypng-go      | 2.5ms     | 17%           | 0             | 1248378.32691  | [dir→](./participantes/samypng-go)                                          |
| 92      | lecosas-java... | 2.34ms    | 17%           | 529154.16645  | 1239732.61854  | [dir→](./participantes/lecosas-java-spring-graalvm-5)                       |
| 93      | arthur-isvi-... | 2.57ms    | 17%           | 0             | 1232016.02316  | [dir→](./participantes/arthur-isvi-php-swoole)                              |
| 94      | yanpitangui-... | 2.54ms    | 17%           | 0             | 1220910.065505 | [dir→](./participantes/yanpitangui-dotnet-v3)                               |
| 95      | phaalonso-ja... | 28.25ms   | 0%            | 655482.219    | 1217324.121    | [dir→](./participantes/phaalonso-java-2)                                    |
| 96      | cleissonbarb... | 5.16ms    | 12%           | 551523.500325 | 1213351.700715 | [dir→](./participantes/cleissonbarbosa-nim)                                 |
| 97      | alanlviana-d... | 3.01ms    | 16%           | 0             | 1208550.56982  | [dir→](./participantes/alanlviana-dotnet-v1)                                |
| 98      | ricassiocost... | 922.63ms  | 0%            | 0             | 1207651.3995   | [dir→](./participantes/ricassiocosta-python)                                |
| 99      | arthur-isvi-... | 3.16ms    | 16%           | 0             | 1206042.19452  | [dir→](./participantes/arthur-isvi-php-swoole-v2)                           |
| 100     | 000_rollback... | 712.17ms  | 0%            | 0             | 1205011.416    | [dir→](./participantes/000_rollback_name_shell-csharp)                      |
| 101     | lpicanco-rust   | 3.31ms    | 15%           | 0             | 1194630.518475 | [dir→](./participantes/lpicanco-rust)                                       |
| 102     | lecosas-java... | 2.85ms    | 16%           | 0             | 1186484.54232  | [dir→](./participantes/lecosas-java-spring-graalvm-4-direct)                |
| 103     | pedrohsb-gol... | 13.41ms   | 0%            | 637730.751    | 1184357.109    | [dir→](./participantes/pedrohsb-golang-fallback)                            |
| 104     | josineyjr-go-4  | 2.08ms    | 18%           | 0             | 1183240.60332  | [dir→](./participantes/josineyjr-go-4)                                      |
| 105     | lecosas-java... | 3.53ms    | 15%           | 0             | 1175826.666075 | [dir→](./participantes/lecosas-java-spring-graalvm-4-direct-sock)           |
| 106     | emiliosheinz-go | 3.87ms    | 14%           | 0             | 1173393.8091   | [dir→](./participantes/emiliosheinz-go)                                     |
| 107     | josineyjr-go-1  | 2.49ms    | 17%           | 0             | 1172996.60868  | [dir→](./participantes/josineyjr-go-1)                                      |
| 108     | josineyjr-go-3  | 2.39ms    | 17%           | 0             | 1172909.99592  | [dir→](./participantes/josineyjr-go-3)                                      |
| 109     | matheusp        | 2.71ms    | 17%           | 500606.97645  | 1172850.63054  | [dir→](./participantes/matheusp)                                            |
| 110     | patrignani-go   | 8.3ms     | 5%            | 574037.464875 | 1148074.92975  | [dir→](./participantes/patrignani-go)                                       |
| 111     | 4emcos-bun-lb   | 2.7ms     | 17%           | 488667.893175 | 1144879.06401  | [dir→](./participantes/4emcos-bun-lb)                                       |
| 112     | lecosas-java... | 2.21ms    | 18%           | 482536.35255  | 1144300.49319  | [dir→](./participantes/lecosas-java-spring-graalvm-4)                       |
| 113     | michelolivei... | 5.48ms    | 11%           | 0             | 1142322.069465 | [dir→](./participantes/micheloliveira-com-dotnet-csharp-grpc)               |
| 114     | pru-async-v5    | 4.47ms    | 13%           | 0             | 1132583.93484  | [dir→](./participantes/pru-async-v5)                                        |
| 115     | 4emcos-bun-l... | 2.83ms    | 16%           | 488333.158425 | 1130142.452355 | [dir→](./participantes/4emcos-bun-lb-fb)                                    |
| 116     | pedropereira... | 25.33ms   | 0%            | 608339.987325 | 1129774.262175 | [dir→](./participantes/pedropereiradev-bun)                                 |
| 117     | michelolivei... | 6.65ms    | 9%            | 0             | 1128491.419065 | [dir→](./participantes/micheloliveira-com-dotnet-csharp-redis-haproxy)      |
| 118     | gustavo-bortoli | 3.82ms    | 14%           | 499697.718975 | 1127889.137115 | [dir→](./participantes/gustavo-bortoli)                                     |
| 119     | lucas-go-01     | 1091.77ms | 0%            | 607095.153    | 1127462.427    | [dir→](./participantes/lucas-go-01)                                         |
| 120     | guidugaich-node | 301.42ms  | 0%            | 0             | 1123088.9205   | [dir→](./participantes/guidugaich-node)                                     |
| 121     | hamilton-gol... | 2.85ms    | 16%           | 484739.075625 | 1121824.717875 | [dir→](./participantes/hamilton-golang-redis)                               |
| 122     | davidalecrim... | 2.6ms     | 17%           | 476555.126775 | 1116500.58273  | [dir→](./participantes/davidalecrim1-go-3)                                  |
| 123     | adrianosilva-go | 2.33ms    | 17%           | 0             | 1114046.276265 | [dir→](./participantes/adrianosilva-go)                                     |
| 124     | pauloSergio-... | 9.96ms    | 2%            | 579583.746    | 1109488.8852   | [dir→](./participantes/pauloSergio-dotnet-01)                               |
| 125     | leorcvargas-... | 3.41ms    | 15%           | 0             | 1108498.99665  | [dir→](./participantes/leorcvargas-thousand-islands)                        |
| 126     | fabianosl1      | 4.22ms    | 14%           | 490658.40705  | 1107486.11877  | [dir→](./participantes/fabianosl1)                                          |
| 127     | pancine-dotn... | 3.01ms    | 16%           | 0             | 1105068.05268  | [dir→](./participantes/pancine-dotnet-aot)                                  |
| 128     | vfabricio-ud... | 3.82ms    | 14%           | 487206.007575 | 1099693.559955 | [dir→](./participantes/vfabricio-uds-greedy)                                |
| 129     | leorcvargas     | 4.13ms    | 14%           | 0             | 1097286.8562   | [dir→](./participantes/leorcvargas)                                         |
| 130     | codevsk-go-1    | 4ms       | 14%           | 483135.5067   | 1090505.85798  | [dir→](./participantes/codevsk-go-1)                                        |
| 131     | pedro-correa... | 10.25ms   | 2%            | 567647.39955  | 1086639.30771  | [dir→](./participantes/pedro-correa-gleam)                                  |
| 132     | phaalonso-ja... | 14.26ms   | 0%            | 580611.739575 | 1078278.944925 | [dir→](./participantes/phaalonso-java-3)                                    |
| 133     | passos-mathe... | 13.14ms   | 0%            | 580223.32095  | 1077557.59605  | [dir→](./participantes/passos-matheus-python-timeout-adaptivo)              |
| 134     | DouglasMorai... | 5.19ms    | 12%           | 488613.3672   | 1074949.40784  | [dir→](./participantes/DouglasMorais-java)                                  |
| 135     | kauan-carval... | 66.81ms   | 0%            | 576023.76825  | 1069758.42675  | [dir→](./participantes/kauan-carvalho-go)                                   |
| 136     | michelolivei... | 4.28ms    | 13%           | 476744.38875  | 1062458.9235   | [dir→](./participantes/micheloliveira-com-dotnet-csharp-grpc-haproxy)       |
| 137     | wlagent         | 197.92ms  | 0%            | 569595.17685  | 1057819.61415  | [dir→](./participantes/wlagent)                                             |
| 138     | dolphs          | 5.05ms    | 12%           | 480260.15625  | 1056572.34375  | [dir→](./participantes/dolphs)                                              |
| 139     | diogomassis-go  | 113.2ms   | 0%            | 567936.450375 | 1054739.122125 | [dir→](./participantes/diogomassis-go)                                      |
| 140     | arthur-seus-... | 3.98ms    | 14%           | 465683.8263   | 1051114.92222  | [dir→](./participantes/arthur-seus-1.0.0)                                   |
| 141     | carlosqsilva-go | 62.07ms   | 0%            | 564679.83915  | 1048691.12985  | [dir→](./participantes/carlosqsilva-go)                                     |
| 142     | wiliansimoes... | 32.32ms   | 0%            | 564041.1063   | 1047504.9117   | [dir→](./participantes/wiliansimoes-dotnet)                                 |
| 143     | kauanmocelin... | 3.61ms    | 15%           | 457829.349075 | 1046467.0836   | [dir→](./participantes/kauanmocelin-quarkus)                                |
| 144     | francoggm-go    | 3.35ms    | 15%           | 457668.086925 | 1046098.4844   | [dir→](./participantes/francoggm-go)                                        |
| 145     | geazi-anc       | 4.35ms    | 13%           | 458805.5535   | 1022480.9478   | [dir→](./participantes/geazi-anc)                                           |
| 146     | robertAlmeida   | 265.55ms  | 0%            | 550403.928375 | 1022178.724125 | [dir→](./participantes/robertAlmeida)                                       |
| 147     | cleissonbarb... | 2.92ms    | 16%           | 437927.78925  | 1013490.02655  | [dir→](./participantes/cleissonbarbosa-lua)                                 |
| 148     | panissetrafa... | 24.78ms   | 0%            | 543179.131425 | 1008761.244075 | [dir→](./participantes/panissetrafael-go)                                   |
| 149     | brunosilvadev   | 306.66ms  | 0%            | 538530.739425 | 1000128.516075 | [dir→](./participantes/brunosilvadev)                                       |
| 150     | murilo-kendj... | 4.15ms    | 14%           | 0             | 998312.84622   | [dir→](./participantes/murilo-kendjy-node)                                  |
| 151     | danielsuhett... | 2.27ms    | 17%           | 424940.291475 | 995574.39717   | [dir→](./participantes/danielsuhett-golang-2)                               |
| 152     | pedrohsb-python | 17.42ms   | 0%            | 533988.2415   | 991692.4485    | [dir→](./participantes/pedrohsb-python)                                     |
| 153     | lecosas-java... | 2.14ms    | 18%           | 416260.1352   | 987131.17776   | [dir→](./participantes/lecosas-java-spring-graalvm-3-limited-worker-final)  |
| 154     | lucas-santana   | 95.07ms   | 0%            | 0             | 984118.962     | [dir→](./participantes/lucas-santana)                                       |
| 155     | joaoxyz-type... | 891.71ms  | 0%            | 0             | 982144.2375    | [dir→](./participantes/joaoxyz-typescript-bun)                              |
| 156     | vimsos-rust     | 28.39ms   | 0%            | 528376.90815  | 981271.40085   | [dir→](./participantes/vimsos-rust)                                         |
| 157     | fabianoflore... | 2.77ms    | 16%           | 423883.455975 | 980987.426685  | [dir→](./participantes/fabianoflorentino)                                   |
| 158     | g4brielV-java1  | 36.22ms   | 0%            | 526690.6029   | 978139.6911    | [dir→](./participantes/g4brielV-java1)                                      |
| 159     | gabxdev-java-3  | 5.77ms    | 10%           | 455627.88915  | 976345.47675   | [dir→](./participantes/gabxdev-java-3)                                      |
| 160     | willianmarqu... | 13.58ms   | 0%            | 520333.379475 | 966333.419025  | [dir→](./participantes/willianmarquess-lua-luvit)                           |
| 161     | ronssm-CopiR... | 908.31ms  | 0%            | 519331.91205  | 964473.55095   | [dir→](./participantes/ronssm-CopiRinhaGo)                                  |
| 162     | gabxdev-java-1  | 5.42ms    | 11%           | 440143.143825 | 955739.39802   | [dir→](./participantes/gabxdev-java-1)                                      |
| 163     | andre-lucas-... | 1087.74ms | 0%            | 514428.574275 | 955367.352225  | [dir→](./participantes/andre-lucas-quarkus)                                 |
| 164     | fuerback-mig... | 68.61ms   | 0%            | 512414.4816   | 951626.8944    | [dir→](./participantes/fuerback-miguel-go)                                  |
| 165     | craytee         | 2.32ms    | 17%           | 0             | 946897.426215  | [dir→](./participantes/craytee)                                             |
| 166     | jorge-java-2    | 5.3ms     | 11%           | 435923.1702   | 946576.02672   | [dir→](./participantes/jorge-java-2)                                        |
| 167     | caiqueborges... | 3.21ms    | 16%           | 0             | 945651.90618   | [dir→](./participantes/caiqueborges-quarkus)                                |
| 168     | asfernandes-... | 4.78ms    | 12%           | 427285.7505   | 940028.6511    | [dir→](./participantes/asfernandes-drogon-lmdb)                             |
| 169     | davigga-node-2  | 41.98ms   | 0%            | 0             | 925513.614     | [dir→](./participantes/davigga-node-2)                                      |
| 170     | arthurbpf-bun   | 25.98ms   | 0%            | 497843.835825 | 924567.123675  | [dir→](./participantes/arthurbpf-bun)                                       |
| 171     | ricardo-santos  | 3.14ms    | 16%           | 0             | 922996.28838   | [dir→](./participantes/ricardo-santos)                                      |
| 172     | phaalonso-ja... | 24.89ms   | 0%            | 494606.803425 | 918555.492075  | [dir→](./participantes/phaalonso-java-1)                                    |
| 173     | pedrohsb-golang | 26.6ms    | 0%            | 494375.43645  | 918125.81055   | [dir→](./participantes/pedrohsb-golang)                                     |
| 174     | pablopavan      | 2.8ms     | 16%           | 392480.49435  | 908312.00121   | [dir→](./participantes/pablopavan)                                          |
| 175     | rst77-final     | 66.19ms   | 0%            | 0             | 898032.282     | [dir→](./participantes/rst77-final)                                         |
| 176     | antooniodev-... | 51ms      | 0%            | 482819.7192   | 896665.1928    | [dir→](./participantes/antooniodev-node)                                    |
| 177     | jjeanjacques10  | 26.2ms    | 0%            | 480510.049425 | 892375.806075  | [dir→](./participantes/jjeanjacques10)                                      |
| 178     | dolphs-go       | 84ms      | 0%            | 477788.59275  | 887321.67225   | [dir→](./participantes/dolphs-go)                                           |
| 179     | jorge-java      | 7.77ms    | 6%            | 434670.756975 | 881760.678435  | [dir→](./participantes/jorge-java)                                          |
| 180     | cgb-go-v2       | 75.85ms   | 0%            | 474651.138675 | 881494.971825  | [dir→](./participantes/cgb-go-v2)                                           |
| 181     | passos-mathe... | 19.95ms   | 0%            | 474159.98385  | 880582.82715   | [dir→](./participantes/passos-matheus-only-default)                         |
| 182     | pru-async       | 37.25ms   | 0%            | 473840.196375 | 879988.936125  | [dir→](./participantes/pru-async)                                           |
| 183     | gustavocesar... | 104.49ms  | 0%            | 471237.4758   | 875155.3122    | [dir→](./participantes/gustavocesario-ktor)                                 |
| 184     | dnery           | 2.75ms    | 17%           | 0             | 869820.06735   | [dir→](./participantes/dnery)                                               |
| 185     | 4emcos-golang   | 86.51ms   | 0%            | 466034.771475 | 865493.147025  | [dir→](./participantes/4emcos-golang)                                       |
| 186     | rodrigo-mili... | 3.11ms    | 16%           | 0             | 862287.32646   | [dir→](./participantes/rodrigo-militao-in-memory-v2)                        |
| 187     | michelolivei... | 2.65ms    | 17%           | 365661.504075 | 856692.66669   | [dir→](./participantes/micheloliveira-com-dotnet-csharp-postgres)           |
| 188     | rodrigodotde... | 695.55ms  | 0%            | 460219.86045  | 854694.02655   | [dir→](./participantes/rodrigodotdev-bun)                                   |
| 189     | hamilton-gol... | 31.59ms   | 0%            | 458157.55755  | 850864.03545   | [dir→](./participantes/hamilton-golang-escovando-bytes-haproxy)             |
| 190     | maxsonferovante | 4.87ms    | 12%           | 386747.8986   | 850845.37692   | [dir→](./participantes/maxsonferovante)                                     |
| 191     | hamilton-gol... | 36.27ms   | 0%            | 458033.558325 | 850633.751175  | [dir→](./participantes/hamilton-golang-escovando-bytes-nginx)               |
| 192     | hamilton-gol... | 41.88ms   | 0%            | 457903.032825 | 850391.346675  | [dir→](./participantes/hamilton-golang-escovando-bits)                      |
| 193     | michelolivei... | 2.77ms    | 16%           | 365840.66085  | 846659.81511   | [dir→](./participantes/micheloliveira-com-dotnet-csharp-postgres-haproxy)   |
| 194     | josimar-silva   | 3.19ms    | 16%           | 0             | 844300.287     | [dir→](./participantes/josimar-silva)                                       |
| 195     | ccs1201-06-n... | 3.31ms    | 15%           | 368366.96085  | 841981.6248    | [dir→](./participantes/ccs1201-06-native-pgo)                               |
| 196     | alexroza-rs     | 1007.96ms | 0%            | 452920.327125 | 841137.750375  | [dir→](./participantes/alexroza-rs)                                         |
| 197     | suricat89-so... | 2.39ms    | 17%           | 358529.9697   | 839984.50044   | [dir→](./participantes/suricat89-solucao1)                                  |
| 198     | joelgarciajr... | 89.53ms   | 0%            | 449935.924725 | 835595.288775  | [dir→](./participantes/joelgarciajr84-go)                                   |
| 199     | libardi-dotn... | 3.04ms    | 16%           | 0             | 834312.1389    | [dir→](./participantes/libardi-dotnet-2)                                    |
| 200     | fabricio-roc... | 6.32ms    | 9%            | 393308.068125 | 831565.62975   | [dir→](./participantes/fabricio-rocha-quarkus)                              |
| 201     | michelolivei... | 2.47ms    | 17%           | 0             | 831500.6076    | [dir→](./participantes/micheloliveira-com-dotnet-csharp-redis)              |
| 202     | wallacemende... | 87.17ms   | 0%            | 446766.260325 | 829708.769175  | [dir→](./participantes/wallacemendes-node)                                  |
| 203     | dearrudam_ja... | 7.11ms    | 8%            | 397215.2016   | 828477.42048   | [dir→](./participantes/dearrudam_java_02)                                   |
| 204     | ccs1201-04-j... | 4.43ms    | 13%           | 368176.014675 | 820506.54699   | [dir→](./participantes/ccs1201-04-java-puro)                                |
| 205     | pru-async-v3    | 4.54ms    | 13%           | 368029.6998   | 820180.47384   | [dir→](./participantes/pru-async-v3)                                        |
| 206     | diogoloff-fp... | 24.91ms   | 0%            | 441071.7696   | 819133.2864    | [dir→](./participantes/diogoloff-fpc-new)                                   |
| 207     | viniciusfonseca | 2.75ms    | 17%           | 0             | 816086.261835  | [dir→](./participantes/viniciusfonseca)                                     |
| 208     | nicolasmmb      | 50.23ms   | 0%            | 436791.3753   | 811183.9827    | [dir→](./participantes/nicolasmmb)                                          |
| 209     | rodrigo-mili... | 3.05ms    | 16%           | 0             | 810905.75286   | [dir→](./participantes/rodrigo-militao-in-memory)                           |
| 210     | ronaldo-silv... | 32.8ms    | 0%            | 436614.744825 | 810855.954675  | [dir→](./participantes/ronaldo-silva-java)                                  |
| 211     | apelisser-v1... | 17.98ms   | 0%            | 435558.751425 | 808894.824075  | [dir→](./participantes/apelisser-v1.3.x)                                    |
| 212     | rodrigo-militao | 5.13ms    | 12%           | 0             | 806871.25176   | [dir→](./participantes/rodrigo-militao)                                     |
| 213     | joyce-go-5      | 2.23ms    | 18%           | 337636.837125 | 800681.642325  | [dir→](./participantes/joyce-go-5)                                          |
| 214     | joyce-go        | 1.95ms    | 18%           | 337506.311625 | 800372.110425  | [dir→](./participantes/joyce-go)                                            |
| 215     | vfabricio-gr... | 4.12ms    | 14%           | 0             | 796585.19274   | [dir→](./participantes/vfabricio-greedy)                                    |
| 216     | diogoloff-de... | 106.11ms  | 0%            | 427621.116825 | 794153.502675  | [dir→](./participantes/diogoloff-delphi)                                    |
| 217     | ba7s-full-rs    | 29.14ms   | 0%            | 426106.8105   | 791341.2195    | [dir→](./participantes/ba7s-full-rs)                                        |
| 218     | joao-bittenc... | 114.85ms  | 0%            | 425723.655    | 790629.645     | [dir→](./participantes/joao-bittencourt-php-redis)                          |
| 219     | joyce-go-3      | 2.33ms    | 17%           | 337362.733575 | 790392.69009   | [dir→](./participantes/joyce-go-3)                                          |
| 220     | pru-async-v4    | 5.44ms    | 11%           | 363115.414725 | 788479.18626   | [dir→](./participantes/pru-async-v4)                                        |
| 221     | diogoloff-de... | 75.08ms   | 0%            | 422491.464675 | 784627.005825  | [dir→](./participantes/diogoloff-delphi-Indy)                               |
| 222     | apelisser-v1... | 9.21ms    | 4%            | 395490.15975  | 779680.60065   | [dir→](./participantes/apelisser-v1.2.0)                                    |
| 223     | pancine-dotnet  | 3.2ms     | 16%           | 333712.86165  | 772306.90839   | [dir→](./participantes/pancine-dotnet)                                      |
| 224     | lpicanco-moo... | 3.26ms    | 15%           | 0             | 767365.820475  | [dir→](./participantes/lpicanco-moonshine)                                  |
| 225     | daniloneto-3    | 2.38ms    | 17%           | 0             | 765820.56096   | [dir→](./participantes/daniloneto-3)                                        |
| 226     | macedot-go-s... | 2.7ms     | 17%           | 0             | 765712.18269   | [dir→](./participantes/macedot-go-silverlining)                             |
| 227     | macedot-go-echo | 2.44ms    | 17%           | 0             | 765668.54988   | [dir→](./participantes/macedot-go-echo)                                     |
| 228     | macedot-go-gear | 2.48ms    | 17%           | 0             | 765559.467855  | [dir→](./participantes/macedot-go-gear)                                     |
| 229     | daniloneto      | 2.25ms    | 18%           | 0             | 764921.25831   | [dir→](./participantes/daniloneto)                                          |
| 230     | lczago-go       | 63.06ms   | 0%            | 409510.7037   | 760519.8783    | [dir→](./participantes/lczago-go)                                           |
| 231     | davidalecrim... | 2.42ms    | 17%           | 324401.551425 | 760026.49191   | [dir→](./participantes/davidalecrim1-go-1)                                  |
| 232     | macedot-go-f... | 2.91ms    | 16%           | 0             | 759167.63412   | [dir→](./participantes/macedot-go-fasthttp)                                 |
| 233     | daniloneto-0    | 2.47ms    | 17%           | 0             | 758429.72595   | [dir→](./participantes/daniloneto-0)                                        |
| 234     | feykke-quarkus  | 3.34ms    | 15%           | 330415.6191   | 755235.7008    | [dir→](./participantes/feykke-quarkus)                                      |
| 235     | pru-async-v6    | 3.5ms     | 15%           | 0             | 752301.433425  | [dir→](./participantes/pru-async-v6)                                        |
| 236     | rafaelpadove... | 3.63ms    | 15%           | 0             | 751478.280675  | [dir→](./participantes/rafaelpadovezi-dotnet)                               |
| 237     | jessicanatha... | 199.49ms  | 0%            | 395517.94905  | 734533.33395   | [dir→](./participantes/jessicanathany-dotnet)                               |
| 238     | arthur-queir... | 82.76ms   | 0%            | 395507.633325 | 734514.176175  | [dir→](./participantes/arthur-queiroz-golang)                               |
| 239     | diofeher-ful... | 2.58ms    | 17%           | 0             | 730260.524565  | [dir→](./participantes/diofeher-full-custom)                                |
| 240     | dearrudam_ja... | 9.92ms    | 2%            | 379672.5744   | 726801.78528   | [dir→](./participantes/dearrudam_java_01)                                   |
| 241     | marcelo-dias... | 2.51ms    | 17%           | 0             | 723541.071825  | [dir→](./participantes/marcelo-dias-skylake)                                |
| 242     | franklaercio    | 987.87ms  | 0%            | 384249.3879   | 713606.0061    | [dir→](./participantes/franklaercio)                                        |
| 243     | joojf-rust      | 82.41ms   | 0%            | 382167.506175 | 709739.654325  | [dir→](./participantes/joojf-rust)                                          |
| 244     | matheusdojava   | 4.25ms    | 14%           | 312680.361525 | 705764.244585  | [dir→](./participantes/matheusdojava)                                       |
| 245     | diogoloff-de... | 82.19ms   | 0%            | 379731.310875 | 705215.291625  | [dir→](./participantes/diogoloff-delphi-new)                                |
| 246     | adriano-moreira | 3.93ms    | 14%           | 0             | 703247.03325   | [dir→](./participantes/adriano-moreira)                                     |
| 247     | rafaspimenta... | 894.56ms  | 0%            | 0             | 698213.3805    | [dir→](./participantes/rafaspimenta-dotnet-multi)                           |
| 248     | ba7s-rs         | 1024.01ms | 0%            | 375623.126025 | 697585.805475  | [dir→](./participantes/ba7s-rs)                                             |
| 249     | wildemberg-s... | 6.57ms    | 9%            | 0             | 696461.39145   | [dir→](./participantes/wildemberg-sales-dotnet)                             |
| 250     | diogoloff-de... | 83.09ms   | 0%            | 372467.5668   | 691725.4812    | [dir→](./participantes/diogoloff-delphi-Indy-new)                           |
| 251     | el_yawd-crab    | 2.45ms    | 17%           | 290974.1814   | 681710.93928   | [dir→](./participantes/el_yawd-crab)                                        |
| 252     | santannaf-ja... | 1005.73ms | 0%            | 366403.18365  | 680463.05535   | [dir→](./participantes/santannaf-java-revolts2)                             |
| 253     | marcosmarcol... | 2.26ms    | 17%           | 289003.456875 | 677093.81325   | [dir→](./participantes/marcosmarcolin-php)                                  |
| 254     | mxlange-only-go | 20.41ms   | 0%            | 361118.374575 | 670648.409925  | [dir→](./participantes/mxlange-only-go)                                     |
| 255     | carlos-demarco  | 49.33ms   | 0%            | 0             | 667725.15      | [dir→](./participantes/carlos-demarco)                                      |
| 256     | leonardotoma... | 4.8ms     | 12%           | 297621.508275 | 654767.318205  | [dir→](./participantes/leonardotomas-cs)                                    |
| 257     | rafaspimenta... | 892.39ms  | 0%            | 0             | 654321.9255    | [dir→](./participantes/rafaspimenta-dotnet)                                 |
| 258     | rafaspimenta... | 889.66ms  | 0%            | 0             | 654265.986     | [dir→](./participantes/rafaspimenta-dotnet-fire-forget)                     |
| 259     | camilo-coelh... | 107.94ms  | 0%            | 351329.1726   | 652468.4634    | [dir→](./participantes/camilo-coelho-spring)                                |
| 260     | henriquevalc... | 1073.61ms | 0%            | 345256.36845  | 641190.39855   | [dir→](./participantes/henriquevalcanaia-swift-vapor)                       |
| 261     | wesley-frias    | 11.39ms   | 0%            | 339800.40255  | 631057.89045   | [dir→](./participantes/wesley-frias)                                        |
| 262     | rafaelberroc... | 4.66ms    | 13%           | 280748.98215  | 625669.16022   | [dir→](./participantes/rafaelberrocalj-dotnet)                              |
| 263     | cleissonbarb... | 3ms       | 16%           | 266872.4373   | 617619.06918   | [dir→](./participantes/cleissonbarbosa-lean4)                               |
| 264     | libardi-dotnet  | 2.87ms    | 16%           | 263230.77585  | 609191.22411   | [dir→](./participantes/libardi-dotnet)                                      |
| 265     | bruno-inacio... | 68.33ms   | 0%            | 324950.3901   | 603479.2959    | [dir→](./participantes/bruno-inacio-dotnet)                                 |
| 266     | joaoprocopio    | 3.25ms    | 16%           | 247881.187575 | 573667.891245  | [dir→](./participantes/joaoprocopio)                                        |
| 267     | juanlimalf-p... | 685.91ms  | 0%            | 0             | 572471.0085    | [dir→](./participantes/juanlimalf-python-fastapi)                           |
| 268     | cgb-go-v1       | 25.88ms   | 0%            | 304547.359725 | 565587.953775  | [dir→](./participantes/cgb-go-v1)                                           |
| 269     | alan-silva      | 5.71ms    | 11%           | 257827.02015  | 559852.95804   | [dir→](./participantes/alan-silva)                                          |
| 270     | gdx64-rs-sqlite | 3.26ms    | 15%           | 244291.5258   | 558380.6304    | [dir→](./participantes/gdx64-rs-sqlite)                                     |
| 271     | jrblatt-rust-v4 | 2.61ms    | 17%           | 236835.782925 | 554872.40571   | [dir→](./participantes/jrblatt-rust-v4)                                     |
| 272     | hamilton-gol... | 1082.38ms | 0%            | 297891.822375 | 553227.670125  | [dir→](./participantes/hamilton-golang-erly)                                |
| 273     | gdx64-rs-uds    | 3.85ms    | 14%           | 244304.57835  | 551430.33399   | [dir→](./participantes/gdx64-rs-uds)                                        |
| 274     | luanvictor-node | 98.72ms   | 0%            | 296580.46215  | 550792.28685   | [dir→](./participantes/luanvictor-node)                                     |
| 275     | jrblatt-rust-v3 | 3.01ms    | 16%           | 236773.257    | 547960.9662    | [dir→](./participantes/jrblatt-rust-v3)                                     |
| 276     | jrblatt-rust-v1 | 2.12ms    | 18%           | 229046.1474   | 543166.57812   | [dir→](./participantes/jrblatt-rust-v1)                                     |
| 277     | flads-go        | 2.08ms    | 18%           | 228967.8321   | 542980.85898   | [dir→](./participantes/flads-go)                                            |
| 278     | gabrieleiro     | 8.1ms     | 6%            | 267224.85615  | 542084.70819   | [dir→](./participantes/gabrieleiro)                                         |
| 279     | rodrigo-mili... | 5.89ms    | 10%           | 252232.5288   | 540498.276     | [dir→](./participantes/rodrigo-militao-v2)                                  |
| 280     | not4rt-corou... | 3.5ms     | 15%           | 236316.41775  | 540151.812     | [dir→](./participantes/not4rt-coroutines_rs)                                |
| 281     | rjsantana       | 437.16ms  | 0%            | 289375.8756   | 537412.3404    | [dir→](./participantes/rjsantana)                                           |
| 282     | rafaelgiori-... | 3.37ms    | 15%           | 0             | 536827.02075   | [dir→](./participantes/rafaelgiori-dotnet)                                  |
| 283     | jrblatt-rust-v2 | 2.47ms    | 17%           | 229129.304775 | 536817.22833   | [dir→](./participantes/jrblatt-rust-v2)                                     |
| 284     | daniloneto-2    | 2.34ms    | 17%           | 229077.936675 | 536696.88021   | [dir→](./participantes/daniloneto-2)                                        |
| 285     | not4rt-uring_rs | 2.63ms    | 17%           | 228974.358375 | 536454.21105   | [dir→](./participantes/not4rt-uring_rs)                                     |
| 286     | danielsuhett... | 2.59ms    | 17%           | 228915.6219   | 536316.59988   | [dir→](./participantes/danielsuhett-golang)                                 |
| 287     | santannaf-ja... | 900.2ms   | 0%            | 288285.145575 | 535386.698925  | [dir→](./participantes/santannaf-java-revolts)                              |
| 288     | lauro-santan... | 2.2ms     | 18%           | 0             | 532614.24708   | [dir→](./participantes/lauro-santana-go)                                    |
| 289     | joao-xavier     | 3.17ms    | 16%           | 229196.251725 | 530425.611135  | [dir→](./participantes/joao-xavier)                                         |
| 290     | thiagorigona... | 2.93ms    | 16%           | 229176.6729   | 530380.30014   | [dir→](./participantes/thiagorigonatti-c)                                   |
| 291     | jrblatt-node... | 2.34ms    | 17%           | 226207.217775 | 529971.19593   | [dir→](./participantes/jrblatt-nodejs-v1)                                   |
| 292     | jrblatt-node... | 2.61ms    | 17%           | 225813.957075 | 529049.84229   | [dir→](./participantes/jrblatt-nodejs-v2)                                   |
| 293     | mxlange-ws      | 2.37ms    | 17%           | 224450.597175 | 525855.68481   | [dir→](./participantes/mxlange-ws)                                          |
| 294     | marcospaulo-... | 3.35ms    | 15%           | 229072.2525   | 523593.72      | [dir→](./participantes/marcospaulo-java-2)                                  |
| 295     | wendelmax       | 2.43ms    | 17%           | 221322.195675 | 518526.28701   | [dir→](./participantes/wendelmax)                                           |
| 296     | cristian-s-b... | 47.1ms    | 0%            | 0             | 505140.903     | [dir→](./participantes/cristian-s-bun-go-1)                                 |
| 297     | edmar-sousa     | 812.8ms   | 0%            | 270561.045825 | 502470.513675  | [dir→](./participantes/edmar-sousa)                                         |
| 298     | mpedroni-go     | 28.14ms   | 0%            | 269802.734775 | 501062.221725  | [dir→](./participantes/mpedroni-go)                                         |
| 299     | oliveigah       | 1003.86ms | 0%            | 269614.73595  | 500713.08105   | [dir→](./participantes/oliveigah)                                           |
| 300     | leoralph        | 6.52ms    | 9%            | 236668.8366   | 500385.54024   | [dir→](./participantes/leoralph)                                            |
| 301     | lipenvs         | 3.77ms    | 14%           | 218297.372475 | 492728.355015  | [dir→](./participantes/lipenvs)                                             |
| 302     | mxlange-cpp     | 4.58ms    | 13%           | 219831.0471   | 489909.19068   | [dir→](./participantes/mxlange-cpp)                                         |
| 303     | davigga-node    | 61.34ms   | 0%            | 261882.9948   | 486354.1332    | [dir→](./participantes/davigga-node)                                        |
| 304     | samuelpanzer... | 3.35ms    | 15%           | 211880.781    | 484298.928     | [dir→](./participantes/samuelpanzera-rs-coroutines)                         |
| 305     | daniilha-php    | 3.16ms    | 16%           | 205106.50755  | 474675.06033   | [dir→](./participantes/daniilha-php)                                        |
| 306     | santannaf       | 983.08ms  | 0%            | 243436.2      | 452095.8       | [dir→](./participantes/santannaf)                                           |
| 307     | vhogemann       | 304.92ms  | 0%            | 0             | 445842.0255    | [dir→](./participantes/vhogemann)                                           |
| 308     | luizcordista-go | 37.8ms    | 0%            | 237278.09595  | 440659.32105   | [dir→](./participantes/luizcordista-go)                                     |
| 309     | nathanfabio-go  | 3.4ms     | 15%           | 192467.42865  | 439925.5512    | [dir→](./participantes/nathanfabio-go)                                      |
| 310     | gabrielluizs... | 28.71ms   | 0%            | 236173.892325 | 438608.657175  | [dir→](./participantes/gabrielluizsf-go)                                    |
| 311     | marcusadrian... | 894.72ms  | 0%            | 232694.335125 | 432146.622375  | [dir→](./participantes/marcusadriano-go)                                    |
| 312     | gabriellucia... | 2.05ms    | 18%           | 182131.703775 | 431912.326095  | [dir→](./participantes/gabrielluciano-quarkus)                              |
| 313     | murilo-guede... | 3.67ms    | 15%           | 186846.200625 | 427077.03      | [dir→](./participantes/murilo-guedes-toloni)                                |
| 314     | jrblatt-node... | 120.75ms  | 0%            | 228176.468625 | 423756.298875  | [dir→](./participantes/jrblatt-nodejs-v4)                                   |
| 315     | gldmelo-cs      | 89.56ms   | 0%            | 227649.52455  | 422777.68845   | [dir→](./participantes/gldmelo-cs)                                          |
| 316     | jrblatt-node... | 150.82ms  | 0%            | 226207.217775 | 420099.118725  | [dir→](./participantes/jrblatt-nodejs-v3)                                   |
| 317     | cavalcanteyury  | 97.67ms   | 0%            | 225571.011225 | 418917.592275  | [dir→](./participantes/cavalcanteyury)                                      |
| 318     | goulart12-do... | 4.25ms    | 14%           | 183160.328925 | 413419.028145  | [dir→](./participantes/goulart12-dotnet)                                    |
| 319     | guilhermesou... | 297.12ms  | 0%            | 221589.77295  | 411523.86405   | [dir→](./participantes/guilhermesouza-nodejs)                               |
| 320     | sylviot         | 2.34ms    | 17%           | 0             | 409915.471095  | [dir→](./participantes/sylviot)                                             |
| 321     | luucaspole-c... | 3.28ms    | 15%           | 179165.406525 | 409520.9292    | [dir→](./participantes/luucaspole-crystal)                                  |
| 322     | libardi-dotn... | 2.77ms    | 16%           | 171130.29885  | 396044.40591   | [dir→](./participantes/libardi-dotnet-3)                                    |
| 323     | bine-rinha-b... | 1454.91ms | 0%            | 212952.35325  | 395482.94175   | [dir→](./participantes/bine-rinha-backend-golang)                           |
| 324     | gabriell915-... | 71.46ms   | 0%            | 205907.555175 | 382399.745325  | [dir→](./participantes/gabriell915-bun-hono-01)                             |
| 325     | ovelha          | 29.07ms   | 0%            | 205142.507325 | 380978.942175  | [dir→](./participantes/ovelha)                                              |
| 326     | mourishitz-go   | 2.53ms    | 17%           | 162553.299825 | 380839.15959   | [dir→](./participantes/mourishitz-go)                                       |
| 327     | lucas-porto-... | 51.46ms   | 0%            | 0             | 380339.277     | [dir→](./participantes/lucas-porto-python-01)                               |
| 328     | victorverdoo... | 32.23ms   | 0%            | 183084.539925 | 340014.145575  | [dir→](./participantes/victorverdoodt-cs-redis)                             |
| 329     | athayr-robyn... | 3.05ms    | 16%           | 132248.226075 | 306060.180345  | [dir→](./participantes/athayr-robyn-python)                                 |
| 330     | thilourenco2... | 35.26ms   | 0%            | 161174.99265  | 299324.98635   | [dir→](./participantes/thilourenco2-node)                                   |
| 331     | thilourenco-... | 49.61ms   | 0%            | 159909.7374   | 296975.2266    | [dir→](./participantes/thilourenco-node)                                    |
| 332     | thilourenco-... | 31.17ms   | 0%            | 159025.321875 | 295332.740625  | [dir→](./participantes/thilourenco-node-2)                                  |
| 333     | felipefrmelo... | 2.81ms    | 16%           | 127527.413475 | 295134.871185  | [dir→](./participantes/felipefrmelo-rust)                                   |
| 334     | felipeamorim... | 3.02ms    | 16%           | 126665.945175 | 293141.187405  | [dir→](./participantes/felipeamorim-rust)                                   |
| 335     | felipeschirmann | 2.94ms    | 16%           | 124577.537175 | 288308.014605  | [dir→](./participantes/felipeschirmann)                                     |
| 336     | guim-ruby       | 193.31ms  | 0%            | 151885.78755  | 282073.60545   | [dir→](./participantes/guim-ruby)                                           |
| 337     | diofeher        | 2.98ms    | 16%           | 120553.3518   | 278994.89988   | [dir→](./participantes/diofeher)                                            |
| 338     | fbafica-go-1    | 2.86ms    | 16%           | 0             | 265996.62924   | [dir→](./participantes/fbafica-go-1)                                        |
| 339     | pru             | 88.4ms    | 0%            | 139134.077775 | 258391.858725  | [dir→](./participantes/pru)                                                 |
| 340     | marcioendo      | 4.51ms    | 13%           | 110972.7801   | 247310.76708   | [dir→](./participantes/marcioendo)                                          |
| 341     | joaoreisa-go    | 11.71ms   | 0%            | 0             | 246302.22      | [dir→](./participantes/joaoreisa-go)                                        |
| 342     | bine-rinha-b... | 1486.69ms | 0%            | 130815.1824   | 242942.4816    | [dir→](./participantes/bine-rinha-backend-react-php)                        |
| 343     | gustavotbett... | 205.51ms  | 0%            | 129341.08635  | 240204.87465   | [dir→](./participantes/gustavotbett-java)                                   |
| 344     | vitor-vale      | 53.71ms   | 0%            | 0             | 238077.309     | [dir→](./participantes/vitor-vale)                                          |
| 345     | lucasvsouza2... | 398.02ms  | 0%            | 0             | 233751.9225    | [dir→](./participantes/lucasvsouza28-bun)                                   |
| 346     | eduardompint... | 53.61ms   | 0%            | 0             | 216669.924     | [dir→](./participantes/eduardompinto-ktor-1)                                |
| 347     | mxlange-fast... | 4.16ms    | 14%           | 93172.89135   | 210304.52619   | [dir→](./participantes/mxlange-fasthttp)                                    |
| 348     | machadoah-py... | 388.98ms  | 0%            | 106655.543925 | 198074.581575  | [dir→](./participantes/machadoah-python-simple)                             |
| 349     | jvsandrade-r... | 1.18ms    | 20%           | 0             | 190060.767     | [dir→](./participantes/jvsandrade-rust-mini)                                |
| 350     | juliotsutsui-go | 62.98ms   | 0%            | 100311.583575 | 186292.940925  | [dir→](./participantes/juliotsutsui-go)                                     |
| 351     | ogabriel-eli... | 1.65ms    | 19%           | 0             | 181131.541605  | [dir→](./participantes/ogabriel-elixir-alt)                                 |
| 352     | joaofsilva-p... | 1.22ms    | 20%           | 0             | 180299.1438    | [dir→](./participantes/joaofsilva-php-swoole)                               |
| 353     | gedun           | 70.98ms   | 0%            | 96279.8193    | 178805.3787    | [dir→](./participantes/gedun)                                               |
| 354     | brunokiau-jvm   | 1.08ms    | 20%           | 69865.24755   | 169672.74405   | [dir→](./participantes/brunokiau-jvm)                                       |
| 355     | leandroalves... | 195.91ms  | 0%            | 0             | 166981.212     | [dir→](./participantes/leandroalves-haskell)                                |
| 356     | xandao-php      | 798.1ms   | 0%            | 80732.127     | 149931.093     | [dir→](./participantes/xandao-php)                                          |
| 357     | cristian-s-n... | 3.4ms     | 15%           | 0             | 135018.494475  | [dir→](./participantes/cristian-s-node-2-http)                              |
| 358     | danielwisky     | 105.78ms  | 0%            | 72184.601475  | 134057.117025  | [dir→](./participantes/danielwisky)                                         |
| 359     | jpgo            | 25.05ms   | 0%            | 70834.05      | 131548.95      | [dir→](./participantes/jpgo)                                                |
| 360     | matheuspaula... | 2.43ms    | 17%           | 52854.4065    | 123830.3238    | [dir→](./participantes/matheuspaula-php)                                    |
| 361     | caiodgallo-go   | 4.95ms    | 12%           | 53267.45655   | 117188.40441   | [dir→](./participantes/caiodgallo-go)                                       |
| 362     | brecabral-go    | 89.27ms   | 0%            | 60165.729225  | 111736.354275  | [dir→](./participantes/brecabral-go)                                        |
| 363     | juanmedeiros... | 2.05ms    | 18%           | 46310.4474    | 109821.91812   | [dir→](./participantes/juanmedeiros-dotnet-redis)                           |
| 364     | rodrigoknol     | 2.83ms    | 16%           | 42730.890825  | 98891.490195   | [dir→](./participantes/rodrigoknol)                                         |
| 365     | 100f-java-1     | 9.6ms     | 3%            | 47710.0176    | 92693.74848    | [dir→](./participantes/100f-java-1)                                         |
| 366     | kauan-carval... | 52ms      | 0%            | 46908.75945   | 87116.26755    | [dir→](./participantes/kauan-carvalho-elixir)                               |
| 367     | dbiagi          | 2.98ms    | 16%           | 37088.399775  | 85833.153765   | [dir→](./participantes/dbiagi)                                              |
| 368     | kauefraga-bu... | 114.89ms  | 0%            | 39901.64535   | 74103.05565    | [dir→](./participantes/kauefraga-bundemais)                                 |
| 369     | vctrhugo-fas... | 1498.33ms | 0%            | 33033.688275  | 61348.278225   | [dir→](./participantes/vctrhugo-fastapi)                                    |
| 370     | lucas-moraes    | 1401.43ms | 0%            | 28642.3473    | 53192.9307     | [dir→](./participantes/lucas-moraes)                                        |
| 371     | willzada-aGO... | 31.33ms   | 0%            | 24535.4256    | 45565.7904     | [dir→](./participantes/willzada-aGOrinha)                                   |
| 372     | andersongome... | 0.89ms    | 20%           | 0             | 44460.7146     | [dir→](./participantes/andersongomes001)                                    |
| 373     | alansouls-do... | 1.78ms    | 18%           | 0             | 38725.0512     | [dir→](./participantes/alansouls-dotnet-aot)                                |
| 374     | teuso99         | 2.55ms    | 17%           | 13757.3877    | 32231.59404    | [dir→](./participantes/teuso99)                                             |
| 375     | santannaf-java  | 1.33ms    | 19%           | 10500.776475  | 25201.86354    | [dir→](./participantes/santannaf-java)                                      |
| 376     | lucas-hsm-ru... | 1.38ms    | 19%           | 10318.040775  | 24763.29786    | [dir→](./participantes/lucas-hsm-rust-mio)                                  |
| 377     | thiagorigona... | 0.76ms    | 20%           | 0             | 24232.9914     | [dir→](./participantes/thiagorigonatti2-c)                                  |
| 378     | josineyjr-go-5  | 1.12ms    | 20%           | 9631.7592     | 23391.4152     | [dir→](./participantes/josineyjr-go-5)                                      |
| 379     | josineyjr-go-2  | 1.09ms    | 20%           | 9392.09355    | 22809.37005    | [dir→](./participantes/josineyjr-go-2)                                      |
| 380     | thiagorigona... | 2.36ms    | 17%           | 0             | 16078.690485   | [dir→](./participantes/thiagorigonatti3-c)                                  |
| 381     | mauricio-can... | 2.53ms    | 17%           | 6728.589525   | 15764.12403    | [dir→](./participantes/mauricio-cantu-2)                                    |
| 382     | maico-smanio... | 1.4ms     | 19%           | 6487.11735    | 15569.08164    | [dir→](./participantes/maico-smaniotto-objpas-pgsql)                        |
| 383     | fernandooliv... | 2.48ms    | 17%           | 6213.0138     | 14556.20376    | [dir→](./participantes/fernandooliveirapimenta-java-01)                     |
| 384     | marincor        | 4.38ms    | 13%           | 0             | 12789.820815   | [dir→](./participantes/marincor)                                            |
| 385     | augustoc100-... | 1390.84ms | 0%            | 6624.169125   | 12302.028375   | [dir→](./participantes/augustoc100-ruby)                                    |
| 386     | rst77           | 47.79ms   | 0%            | 6467.959575   | 12011.924925   | [dir→](./participantes/rst77)                                               |
| 387     | rodrigo-scho... | 36.25ms   | 0%            | 6265.224      | 11635.416      | [dir→](./participantes/rodrigo-schonardt-go)                                |
| 388     | djbrunomonteiro | 1389.62ms | 0%            | 4353.657      | 8085.363       | [dir→](./participantes/djbrunomonteiro)                                     |
| 389     | josafaveriss... | 47.9ms    | 0%            | 3961.448925   | 7356.976575    | [dir→](./participantes/josafaverissimo-java-01)                             |
| 390     | felipewaku      | 100.16ms  | 0%            | 3922.291275   | 7284.255225    | [dir→](./participantes/felipewaku)                                          |
| 391     | joaoulian       | 7.72ms    | 7%            | 2406.747      | 4951.0224      | [dir→](./participantes/joaoulian)                                           |
| 392     | leonardosegf... | 18.08ms   | 0%            | 0             | 4195.4625      | [dir→](./participantes/leonardosegfault-nodejs)                             |
| 393     | lecosas-java... | 2.03ms    | 18%           | 1357.4652     | 3219.13176     | [dir→](./participantes/lecosas-java-spring)                                 |
| 394     | lcarbornar-node | 1456.08ms | 0%            | 1533.674625   | 2848.252875    | [dir→](./participantes/lcarbornar-node)                                     |
| 395     | willzada-BUN... | 7.08ms    | 8%            | 0             | 1922.22558     | [dir→](./participantes/willzada-BUNrinha)                                   |
| 396     | gu-silva-oli... | 3.79ms    | 14%           | 789.679275    | 1782.418935    | [dir→](./participantes/gu-silva-oliveira-02)                                |
| 397     | gu-silva-oli... | 5.31ms    | 11%           | 717.89025     | 1558.8474      | [dir→](./participantes/gu-silva-oliveira-01)                                |
| 398     | joao-vitor-node | 2.45ms    | 17%           | 313.2612      | 733.92624      | [dir→](./participantes/joao-vitor-node)                                     |
| 399     | anibalferrei... | 685.68ms  | 0%            | 143.57805     | 266.64495      | [dir→](./participantes/anibalferreira-rust)                                 |
| 400     | adryan1928-f... | 38.16ms   | 0%            | 137.051775    | 254.524725     | [dir→](./participantes/adryan1928-fastapi)                                  |
| 401     | alcides-e-an... | 837.96ms  | 0%            | 117.47295     | 218.16405      | [dir→](./participantes/alcides-e-antonio)                                   |
| 402     | guilhermegul... | 1387.23ms | 0%            | 0             | 55.9395        | [dir→](./participantes/guilhermegules-payflow-node)                         |
| --      | rolesosi        | 406.57ms  | 0%            | 0             | 0              | [dir→](./participantes/rolesosi)                                            |
| --      | adaopedro-ph... | 5.59ms    | 11%           | 0             | 0              | [dir→](./participantes/adaopedro-php-reactphp-v1)                           |
| --      | alvesluc-node   | 2.52ms    | 17%           | 0             | 0              | [dir→](./participantes/alvesluc-node)                                       |
| --      | Gabriel-Golang  | 4.43ms    | 13%           | 0             | 0              | [dir→](./participantes/Gabriel-Golang)                                      |
| --      | joseeduardo-... | 203.19ms  | 0%            | 0             | 0              | [dir→](./participantes/joseeduardo-node)                                    |
| --      | arthur-r-oli... | 4.38ms    | 13%           | 0             | 0              | [dir→](./participantes/arthur-r-oliveira)                                   |
| --      | IgorFVicente    | 4.93ms    | 12%           | 0             | 0              | [dir→](./participantes/IgorFVicente)                                        |
| --      | abel-golang     | 7.17ms    | 8%            | 0             | 0              | [dir→](./participantes/abel-golang)                                         |
| --      | gui-anacleto... | 192.1ms   | 0%            | 0             | 0              | [dir→](./participantes/gui-anacleto-python-0001)                            |
| --      | gtiburcio-go    | 4.04ms    | 14%           | 0             | 0              | [dir→](./participantes/gtiburcio-go)                                        |
| --      | lucaslimafer... | 2.71ms    | 17%           | 0             | 0              | [dir→](./participantes/lucaslimafernandes)                                  |
| --      | leeozaka-dotnet | 3.13ms    | 16%           | 0             | 0              | [dir→](./participantes/leeozaka-dotnet)                                     |
| --      | ViniciusAlex... | 4.76ms    | 12%           | 0             | 0              | [dir→](./participantes/ViniciusAlexsander-python)                           |
| --      | vyctor-nestjs   | 30.68ms   | 0%            | 0             | 0              | [dir→](./participantes/vyctor-nestjs)                                       |
| --      | dinossauro      | 4.42ms    | 13%           | 0             | 0              | [dir→](./participantes/dinossauro)                                          |
| --      | mdantas-rust    | 4.45ms    | 13%           | 0             | 0              | [dir→](./participantes/mdantas-rust)                                        |
| --      | MathausCarva... | 5.64ms    | 11%           | 0             | 0              | [dir→](./participantes/MathausCarvalhoNode)                                 |
| --      | lhuizf-dotnet   | 3.2ms     | 16%           | 0             | 0              | [dir→](./participantes/lhuizf-dotnet)                                       |
| --      | juanmedeiros... | 29.42ms   | 0%            | 0             | 0              | [dir→](./participantes/juanmedeiros-dotnet)                                 |
| --      | joaocrulhas-... | 111.69ms  | 0%            | 0             | 0              | [dir→](./participantes/joaocrulhas-nestjs-ts)                               |
| --      | lucas-lima-c... | 3.04ms    | 16%           | 0             | 0              | [dir→](./participantes/lucas-lima-chaves)                                   |
| --      | lmtani          | 9.83ms    | 2%            | 0             | 0              | [dir→](./participantes/lmtani)                                              |
| --      | Maxel-Uds-qu... | 4.71ms    | 13%           | 0             | 0              | [dir→](./participantes/Maxel-Uds-quarkus)                                   |
| --      | felipemcassiano | 55.53ms   | 0%            | 0             | 0              | [dir→](./participantes/felipemcassiano)                                     |
| --      | krymancer       | 21.37ms   | 0%            | 0             | 0              | [dir→](./participantes/krymancer)                                           |
| --      | White1Lopes     | 5.9ms     | 10%           | 0             | 0              | [dir→](./participantes/White1Lopes)                                         |
| --      | ndulo-node      | 54.38ms   | 0%            | 0             | 0              | [dir→](./participantes/ndulo-node)                                          |
| --      | boaglio-play... | 66.6ms    | 0%            | 0             | 0              | [dir→](./participantes/boaglio-player456)                                   |
| --      | geffersonFer... | 64.69ms   | 0%            | 0             | 0              | [dir→](./participantes/geffersonFerraz-go)                                  |
| --      | Maxel-Uds-qu... | 6.01ms    | 10%           | 0             | 0              | [dir→](./participantes/Maxel-Uds-quarkus-java-21)                           |

### Submissões com Erro

| participante                        | submissão                                                   |
| ----------------------------------- | ----------------------------------------------------------- |
| alvesa                              | [logs](./participantes/alvesa)                              |
| andersonhqds-node                   | [logs](./participantes/andersonhqds-node)                   |
| andre-nicoletti                     | [logs](./participantes/andre-nicoletti)                     |
| arthurandrade                       | [logs](./participantes/arthurandrade)                       |
| brinobruno-elixir                   | [logs](./participantes/brinobruno-elixir)                   |
| caio-caminha-kotlin                 | [logs](./participantes/caio-caminha-kotlin)                 |
| christian-rust                      | [logs](./participantes/christian-rust)                      |
| chrisx                              | [logs](./participantes/chrisx)                              |
| d4vz                                | [logs](./participantes/d4vz)                                |
| davidalecrim1-go-2                  | [logs](./participantes/davidalecrim1-go-2)                  |
| davidbeyda-go                       | [logs](./participantes/davidbeyda-go)                       |
| dearrudam_java_03                   | [logs](./participantes/dearrudam_java_03)                   |
| developerarthur                     | [logs](./participantes/developerarthur)                     |
| dotnetRinha                         | [logs](./participantes/dotnetRinha)                         |
| drope-dev-rinha-backend-node        | [logs](./participantes/drope-dev-rinha-backend-node)        |
| eduardofp17-node                    | [logs](./participantes/eduardofp17-node)                    |
| emilemoraes-java                    | [logs](./participantes/emilemoraes-java)                    |
| fhgm-dani-ed                        | [logs](./participantes/fhgm-dani-ed)                        |
| gabriel-crispim                     | [logs](./participantes/gabriel-crispim)                     |
| gabriel-nardelli-perl-mojolicious   | [logs](./participantes/gabriel-nardelli-perl-mojolicious)   |
| gemersondenner                      | [logs](./participantes/gemersondenner)                      |
| githiago-f                          | [logs](./participantes/githiago-f)                          |
| gui9394                             | [logs](./participantes/gui9394)                             |
| guisandroni-bun                     | [logs](./participantes/guisandroni-bun)                     |
| gustavo-miranda                     | [logs](./participantes/gustavo-miranda)                     |
| gustavo-paes-kotlin                 | [logs](./participantes/gustavo-paes-kotlin)                 |
| henriqueramos13-node                | [logs](./participantes/henriqueramos13-node)                |
| hfurlan-java-v1                     | [logs](./participantes/hfurlan-java-v1)                     |
| hoffmano                            | [logs](./participantes/hoffmano)                            |
| joao-bittencourt-php                | [logs](./participantes/joao-bittencourt-php)                |
| joaocrleite-go-1                    | [logs](./participantes/joaocrleite-go-1)                    |
| joaoprado-java-spring               | [logs](./participantes/joaoprado-java-spring)               |
| joney-sousa-pereira                 | [logs](./participantes/joney-sousa-pereira)                 |
| josehelioaraujo-v2                  | [logs](./participantes/josehelioaraujo-v2)                  |
| josehelioaraujo                     | [logs](./participantes/josehelioaraujo)                     |
| jotaviobiondo-elixir                | [logs](./participantes/jotaviobiondo-elixir)                |
| julio-fastapi                       | [logs](./participantes/julio-fastapi)                       |
| julipinto-elixir-vanilla            | [logs](./participantes/julipinto-elixir-vanilla)            |
| jvcouto-go                          | [logs](./participantes/jvcouto-go)                          |
| kauanborges-2                       | [logs](./participantes/kauanborges-2)                       |
| kauanborges-3                       | [logs](./participantes/kauanborges-3)                       |
| kauanborges                         | [logs](./participantes/kauanborges)                         |
| lbattochio-dotnet                   | [logs](./participantes/lbattochio-dotnet)                   |
| luisfadini-nodejs                   | [logs](./participantes/luisfadini-nodejs)                   |
| marcospaulo-java-1                  | [logs](./participantes/marcospaulo-java-1)                  |
| mateuxlucax-elysia                  | [logs](./participantes/mateuxlucax-elysia)                  |
| matheusf-lucas-and-luis-java1       | [logs](./participantes/matheusf-lucas-and-luis-java1)       |
| matheusf-lucas-and-luizcastro-java2 | [logs](./participantes/matheusf-lucas-and-luizcastro-java2) |
| mauricio-cantu-3                    | [logs](./participantes/mauricio-cantu-3)                    |
| mauricio-cantu-4                    | [logs](./participantes/mauricio-cantu-4)                    |
| maxsonferovante-spring-mongo        | [logs](./participantes/maxsonferovante-spring-mongo)        |
| mbenencase-python                   | [logs](./participantes/mbenencase-python)                   |
| medisco-go                          | [logs](./participantes/medisco-go)                          |
| ogabriel-ruby-rage                  | [logs](./participantes/ogabriel-ruby-rage)                  |
| oornnery                            | [logs](./participantes/oornnery)                            |
| ortisan-rust                        | [logs](./participantes/ortisan-rust)                        |
| passos-matheus-python-v1            | [logs](./participantes/passos-matheus-python-v1)            |
| phalabadessa-rust-redis-v1          | [logs](./participantes/phalabadessa-rust-redis-v1)          |
| ptronico-python                     | [logs](./participantes/ptronico-python)                     |
| rafael-mendes                       | [logs](./participantes/rafael-mendes)                       |
| raphaeldiasc21-nodejs               | [logs](./participantes/raphaeldiasc21-nodejs)               |
| ricardo-dotnet                      | [logs](./participantes/ricardo-dotnet)                      |
| rodrixl                             | [logs](./participantes/rodrixl)                             |
| ryangst-bun                         | [logs](./participantes/ryangst-bun)                         |
| ryrden-clojure                      | [logs](./participantes/ryrden-clojure)                      |
| samuka7abr-golang                   | [logs](./participantes/samuka7abr-golang)                   |
| samypng-go-2                        | [logs](./participantes/samypng-go-2)                        |
| tvillani-java                       | [logs](./participantes/tvillani-java)                       |
| ventopreto                          | [logs](./participantes/ventopreto)                          |
| vfabricio-custom-queue              | [logs](./participantes/vfabricio-custom-queue)              |
| victorcoelh-python-fastapi          | [logs](./participantes/victorcoelh-python-fastapi)          |
| victorsantos-node                   | [logs](./participantes/victorsantos-node)                   |
| victorverdoodt-cs                   | [logs](./participantes/victorverdoodt-cs)                   |
| vitorvezani-golang                  | [logs](./participantes/vitorvezani-golang)                  |
| wanderdotnet                        | [logs](./participantes/wanderdotnet)                        |
| wellington-pacheco-ets              | [logs](./participantes/wellington-pacheco-ets)              |
| wellington-pacheco-pg               | [logs](./participantes/wellington-pacheco-pg)               |
| wendelllsc                          | [logs](./participantes/wendelllsc)                          |
